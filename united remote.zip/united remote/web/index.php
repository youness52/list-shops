<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Nearby shops</title>
      <!--/tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Elite Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
         Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
      <script > addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
         function hideURLbar(){ window.scrollTo(0,1); } 
      </script>
      <!--//tags -->
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
      <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
      <link href="css/font-awesome.css" rel="stylesheet">
      <link href="css/easy-responsive-tabs.css" rel='stylesheet' type='text/css'/>
      <!-- //for bootstrap working -->
      <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
      <link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
   </head>
   <body>
      <!-- /script for calcul distance between two point -->
      <?php
         session_start();
         function get_ip(){
         if (isset($_SERVER['HTTP_CLIENT_IP'])) {
           return $_SERVER['HTTP_CLIENT_IP'];
         
         } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
           return $_SERVER['HTTP_X_FORWARDED_FOR'];
         }
         }
         $ip=get_ip();
         $query=@unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
         /*
         echo "country".$query['country']."<br/>";
         echo "country".$query['regionName']."<br/>";
         echo "country".$query['city']."<br/>";
         echo "country".$query['lat']."<br/>";
         echo "country".$query['lon']."<br/>";
         */
         $lat=$query['lat'];
         $lon=$query['lon'];
         function distance($lat1, $lon1, $lat2, $lon2, $unit) {
           $theta = $lon1 - $lon2;
           $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
           $dist = acos($dist);
           $dist = rad2deg($dist);
           $miles = $dist * 60 * 1.1515;
           $unit = strtoupper($unit);
         
           if ($unit == "K") {
               return ($miles * 1.609344);
           } else if ($unit == "N") {
               return ($miles * 0.8684);
           } else {
               return $miles;
           }
         }
         $t=time();
         ?>
      <!-- //script for calcul distance between two point -->
      <!-- header -->
      <div class="header" id="home">
         <div class="container">
            <ul>
               <li> <a href="#" data-toggle="modal" data-target="#myModal"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Sign In </a></li>
               <li> <a href="#" data-toggle="modal" data-target="#myModal2"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Sign Up </a></li>
               <li>
                  <form action="" method="post"> <button type="submit" name="logout" class="btn btn-primary btn-sm">Log out</button></form>
               </li>
            </ul>
         </div>
      </div>
      <!-- //header -->
      <?php
         if (isset($_POST['logout'])) {
         $_SESSION["iduser"]="";
         }
         ?>
      <!-- Modal1 -->
      <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
               </div>
               <div class="modal-body modal-body-sub_agile">
                  <div class="col-md-8 modal_body_left modal_body_left1">
                     <h3 class="agileinfo_sign">Sign In <span>Now</span></h3>
                     <form action="" method="post">
                        <div class="styled-input agile-styled-input-top">
                           <input type="email" name="Email" required="">
                           <label>Email</label>
                           <span></span>
                        </div>
                        <div class="styled-input">
                           <input type="password" name="password" required=""> 
                           <label>Password</label>
                           <span></span>
                        </div>
                        <input type="submit" value="Sign In" name="Sign_In">
                     </form>
                     <ul class="social-nav model-3d-0 footer-social w3_agile_social top_agile_third">
                        <li>
                           <a href="#" class="facebook">
                              <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
                              <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div>
                           </a>
                        </li>
                        <li>
                           <a href="#" class="twitter">
                              <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
                              <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div>
                           </a>
                        </li>
                        <li>
                           <a href="#" class="instagram">
                              <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                              <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                           </a>
                        </li>
                        <li>
                           <a href="#" class="pinterest">
                              <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
                              <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
                           </a>
                        </li>
                     </ul>
                     <div class="clearfix"></div>
                     <p><a href="#" data-toggle="modal" data-target="#myModal2" > Don't have an account?</a></p>
                  </div>
                  <div class="clearfix"></div>
               </div>
            </div>
            <!-- //Modal content-->
         </div>
      </div>
      <!-- //Modal1 -->
      <!-- /script for sing in -->
      <?php
         $db = mysqli_connect('localhost','root','','shops') or die('error connection');
         if (isset($_POST['Sign_In'])) {
             $n1=$_POST['Email'];
             $n2=$_POST['password'];
             $query = "SELECT * FROM user where email='$n1' and password_u='$n2'";
         mysqli_query($db, $query) or die('Error querying database.');
         $result = mysqli_query($db, $query);
         $row = mysqli_fetch_array($result);
         if ($row>0) {
         $_SESSION["name"]=$row['name'];
         $_SESSION["iduser"]=$row['id'];
         }else {
         	echo"<h4>Your email or your password incorect</h4>";
         } 
         }
         mysqli_close($db);
         
         ?>
      <!-- //script for sing in -->
      <!-- Modal2 -->
      <div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
               </div>
               <div class="modal-body modal-body-sub_agile">
                  <div class="col-md-8 modal_body_left modal_body_left1">
                     <h3 class="agileinfo_sign">Sign Up <span>Now</span></h3>
                     <form action="" method="post">
                        <div class="styled-input agile-styled-input-top">
                           <input type="text" name="Name" required="">
                           <label>Name</label>
                           <span></span>
                        </div>
                        <div class="styled-input">
                           <input type="email" name="Email" required=""> 
                           <label>Email</label>
                           <span></span>
                        </div>
                        <div class="styled-input">
                           <input type="password" name="password" required=""> 
                           <label>Password</label>
                           <span></span>
                        </div>
                        <div class="styled-input">
                           <input type="password" name="Confirm" required=""> 
                           <label>Confirm Password</label>
                           <span></span>
                        </div>
                        <input type="submit" value="Sign Up" name="Sign_Up">
                     </form>
                     <ul class="social-nav model-3d-0 footer-social w3_agile_social top_agile_third">
                        <li>
                           <a href="#" class="facebook">
                              <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
                              <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div>
                           </a>
                        </li>
                        <li>
                           <a href="#" class="twitter">
                              <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
                              <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div>
                           </a>
                        </li>
                        <li>
                           <a href="#" class="instagram">
                              <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                              <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                           </a>
                        </li>
                        <li>
                           <a href="#" class="pinterest">
                              <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
                              <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
                           </a>
                        </li>
                     </ul>
                     <div class="clearfix"></div>
                     <p><a href="#">By clicking register, I agree to your terms</a></p>
                  </div>
                  <div class="clearfix"></div>
               </div>
            </div>
            <!-- //Modal content-->
         </div>
      </div>
      <!-- //Modal2 -->
      <!-- /script for sing up -->
      <?php
         $db = mysqli_connect('localhost','root','','shops') or die('error connection');
         if (isset($_POST['Sign_Up'])) {
             $n1=$_POST['Name'];
             $n2=$_POST['Email'];
             $n3=$_POST['password'];
         		$n4=$_POST['Confirm'];
             if ($n3==$n4) {
         		$sql = "INSERT INTO `user` (`id`, `name`, `email`, `password_u`) VALUES (NULL, '$n1', '$n2', '$n3')";  
         		mysqli_query($db, $sql) or die('error query sing up') ;
         	$query = "SELECT * FROM user where email='$n2' and password_u='$n3'";
         mysqli_query($db, $query) or die('Error querying database.');
         $result = mysqli_query($db, $query);
         $row = mysqli_fetch_array($result);
         if ($row>0) {
         $_SESSION["name"]=$row['name'];
         $_SESSION["iduser"]=$row['id'];
         }
         		}else {
         			echo "<h4>Your confirm password incorect</h4>";
         		}
             
         }
         mysqli_close($db);
         ?>
      <!-- //script for sing up -->
      <!-- /script for check if user login or not -->
      <?PHP
         try {
         	$_SESSION["iduser"]=$_SESSION["iduser"];//code...
         } catch (\Throwable $th) {
         	$_SESSION["iduser"]="";
         }
         	
         if ($_SESSION["iduser"]) { ?>
      <!-- /7script for check if user login or not -->
      <!-- /new_arrivals --> 
      <div class="new_arrivals_agile_w3ls_info" id="new_arrivals_agile_w3ls_info">
         <div class="container">
            <h3 class="wthree_text_info">Welcome <span><?php echo $_SESSION["name"];  ?></span></h3>
            <div id="horizontalTab" >
               <ul class="resp-tabs-list" id="resp-tabs-list">
                  <li><i class="fa fa-map-marker"></i> NEARBY SHOPS</li>
                  <li><i class="fa fa-heart"></i> MY PREFERRED SHOPS</li>
                  <li> <i class="fa fa-user-circle-o"></i> <?php echo $_SESSION["name"];?></li>
                  <li> <i class="fa fa-info-circle"></i> ABOUT</li>
               </ul>
               <div class="resp-tabs-container">
                  <!--/tab_one-->
                  <!-- /script for remove liked store -->
                  <?php
                     $iduserlike=$_SESSION["iduser"];
                     $db = mysqli_connect('localhost','root','','shops') or die('error connection');
                     if (isset($_POST['Remove'])) {
                         $n2=$_POST['idstore'];
                     		$sql = "DELETE  FROM tlike WHERE iduser='$iduserlike' and idstore='$n2'";  
                         mysqli_query($db, $sql) or die('error query') ;  
                     }
                     mysqli_close($db);
                     ?>
                  <!-- //script for remove liked store -->
                  <!-- /script for add store to list of preefer store -->
                  <?php
                     $iduserlike=$_SESSION["iduser"];
                     $db = mysqli_connect('localhost','root','','shops') or die('error connection');
                     if (isset($_POST['Like'])) {
                         $n2=$_POST['idstore'];
                     		$sql = "INSERT INTO `tlike` (`id`, `iduser`, `idstore`) VALUES (NULL, '$iduserlike','$n2')";  
                         mysqli_query($db, $sql) or die('error query') ;  
                     }
                     mysqli_close($db);
                     ?>
                  <!-- //script for add store to list of preefer store -->
                  <!-- /script for add store to dislake store -->
                  <?php
                     $iduserlike=$_SESSION["iduser"];
                     $db = mysqli_connect('localhost','root','','shops') or die('error connection');
                     if (isset($_POST['DisLike'])) {
                     		$n2=$_POST['idstore'];
                     		$t=time();
                     		$t=$t+7200;
                     		$sql = "INSERT INTO `dislike` (`id`, `iduser`, `idstore`, `dltime`) VALUES (NULL, '$iduserlike','$n2','$t')";  
                         mysqli_query($db, $sql) or die('error query') ;  
                     }
                     mysqli_close($db);
                     ?>
                  <!-- //script for add store to dislake store -->
                  <!-- /script for check if any dislike store  -->
                  <?php
                     $iduserlike=$_SESSION["iduser"];
                     $db = mysqli_connect('localhost','root','','shops') or die('error connection');
                     		
                     		$t=time();
                     		$sql = "DELETE FROM dislike WHERE dislike.dltime<'$t'";  
                         mysqli_query($db, $sql) or die('error query') ;  
                     
                     mysqli_close($db);
                     ?>
                  <!-- //script for check if any dislike store  -->
                  <div class="tab1">
                     <!-- /script for display all store  -->
                     <?php
                        $iduserlike=$_SESSION["iduser"];
                        $db = mysqli_connect('localhost','root','','shops') or die('error connection');
                        $query = "SELECT store.* FROM store,user, tlike WHERE (store.id not in(SELECT tlike.idstore from tlike WHERE tlike.iduser='$iduserlike')) and (store.id not in(SELECT dislike.idstore from dislike WHERE dislike.iduser='$iduserlike')) group BY store.id ";
                        mysqli_query($db, $query) or die('Error querying database.');
                        $result = mysqli_query($db, $query);
                        while ($row = mysqli_fetch_array($result)) {
                        	$latdata=$row['latitude'];
                        	$londata=$row['longitude'];
                        	$vardistance2=distance($lat, $lon, $latdata, $londata, "K");
                        	$vardistance= round($vardistance2,2,PHP_ROUND_HALF_UP);
                        	$id=$row['id'];
                        	$name=$row['name'];
                        	$address=$row['address'];
                        	$image=$row['image'];
                        	$data[]=array('kid'=>$id,'kname'=>$name,'kaddress'=>$address,'kdistance'=>$vardistance,'kimage'=>$image);
                        
                        }
                        foreach ($data as $key => $rows) {
                        	$kid[$key]=$rows['kid'];
                        	$kname[$key]=$rows['kname'];
                        	$kaddress[$key]=$rows['kaddress'];
                        	$kdistance[$key]=$rows['kdistance'];
                        	$kimage[$key]=$rows['kimage'];
                        }
                        $kid=array_column($data,'kid');
                        $kname=array_column($data,'kname');
                        $kaddress=array_column($data,'kaddress');
                        $kdistance=array_column($data,'kdistance');
                        $kimage=array_column($data,'kimage');
                        array_multisort($kdistance,SORT_ASC,$data);
                        
                        	?>
                     <?php
                        for ($i=0; $i <count($data) ; $i++) { 
                        echo "  <div class='col-md-3 product-men'>
                        <div class='men-pro-item simpleCart_shelfItem'>
                        <div class='men-thumb-item'>";
                        $vardistance2= round($vardistance,2,PHP_ROUND_HALF_UP);
                        echo		'<img src="images/'.$data[$i]['kimage'].'" alt="" class="pro-image-front">';
                        echo		'<img src="images/'.$data[$i]['kimage'].'" alt="" class="pro-image-back">';
                        	echo "		
                        	<div class='men-cart-pro'>
                        			<div class='inner-men-cart-pro'>
                        				<a href='single.html' class='link-product-add-cart'>Quick View</a>
                        			</div>
                        		</div>
                        		<span class='product-new-top'>".$data[$i]['kdistance'] ." Km</span>
                        		
                        </div>
                        <div class='item-info-product '>
                        	<h3><a href='single.html'>".$data[$i]['kname']."</a></h3>
                        	<div class='info-product-price'>
                        		<span class='item_price'>".$data[$i]['kaddress']."</span>
                        	</div>
                        	
                        						<form action='' method='post'>
                        						<input type='hidden' name='idstore' value='".$data[$i]['kid']."'>
                        						<button class='btn btn-danger' type='submit' name='DisLike'><i class='fa fa-thumbs-o-down'></i></button>
                        						<button class='btn btn-primary' type='submit' name='Like'><i class='fa fa-thumbs-o-up'></i></button>
                        						</form>								
                        </div>
                        </div>
                        </div> ";
                        }
                        
                        mysqli_close($db);
                        unset($data);
                        ?>
                     <!-- //script for display all store  -->
                     <div class="clearfix"></div>
                  </div>
                  <!--//tab_one-->
                  <!--/tab_two-->
                  <div class="tab2">
                     <!-- /script for display all store Likes  -->
                     <?php
                        $islike=FALSE;
                        $iduserlike=$_SESSION["iduser"];
                        if ($iduserlike!='') {
                        $db = mysqli_connect('localhost','root','','shops') or die('error connection');
                        $query = "SELECT store.* FROM store,user, tlike WHERE store.id in(SELECT tlike.idstore from tlike WHERE tlike.iduser='$iduserlike') group BY store.id ";
                        mysqli_query($db, $query) or die('Error querying database.');
                        $result = mysqli_query($db, $query);
                        
                        while ($row = mysqli_fetch_array($result)) {
                        $islike=TRUE;
                        $latdata=$row['latitude'];
                        $londata=$row['longitude'];
                        $vardistance2=distance($lat, $lon, $latdata, $londata, "K");
                        $vardistance= round($vardistance2,2,PHP_ROUND_HALF_UP);
                        $id=$row['id'];
                        $name=$row['name'];
                        $address=$row['address'];
                        $image=$row['image'];
                        $data[]=array('kid'=>$id,'kname'=>$name,'kaddress'=>$address,'kdistance'=>$vardistance,'kimage'=>$image);
                        
                        }
                        if ($islike===TRUE){
                        foreach ($data as $key => $rows) {
                        $kid[$key]=$rows['kid'];
                        $kname[$key]=$rows['kname'];
                        $kaddress[$key]=$rows['kaddress'];
                        $kdistance[$key]=$rows['kdistance'];
                        $kimage[$key]=$rows['kimage'];
                        }
                        $kid=array_column($data,'kid');
                        $kname=array_column($data,'kname');
                        $kaddress=array_column($data,'kaddress');
                        $kdistance=array_column($data,'kdistance');
                        $kimage=array_column($data,'kimage');
                        array_multisort($kdistance,SORT_ASC,$data);
                        
                        ?>
                     <?php
                        for ($i=0; $i <count($data) ; $i++) { 
                        echo "  <div class='col-md-3 product-men'>
                        <div class='men-pro-item simpleCart_shelfItem'>
                        <div class='men-thumb-item'>";
                        $vardistance2= round($vardistance,2,PHP_ROUND_HALF_UP);
                        echo		'<img src="images/'.$data[$i]['kimage'].'" alt="" class="pro-image-front">';
                        echo		'<img src="images/'.$data[$i]['kimage'].'" alt="" class="pro-image-back">';
                        	echo "		
                        	<div class='men-cart-pro'>
                        			<div class='inner-men-cart-pro'>
                        				<a href='single.html' class='link-product-add-cart'>Quick View</a>
                        			</div>
                        		</div>
                        		<span class='product-new-top'>".$data[$i]['kdistance'] ." Km</span>
                        		
                        </div>
                        <div class='item-info-product '>
                        	<h3><a href='single.html'>".$data[$i]['kname']."</a></h3>
                        	<div class='info-product-price'>
                        		<span class='item_price'>".$data[$i]['kaddress']."</span>
                        	</div>
                        	
                        						<form action='' method='post'>
                        						<input type='hidden' name='idstore' value='".$data[$i]['kid']."'>
                        						<button class='btn btn-primary' type='submit' name='Remove'><i class='fa fa-trash-o'></i></button>
                        						</form>								
                        </div>
                        </div>
                        </div> ";
                        }
                        
                        
                        unset($data);
                        	}else {
                        		echo "You don't like any store";
                        	}
                        }
                        mysqli_close($db);
                        ?>
                     <!-- //script for display all store Likes  -->
                     <div class="clearfix"></div>
                  </div>
                  <!--//tab_two-->
                  <div class="tab3">
                     <br><br>
                     <h3 class="wthree_text_info"><span>Tab still under development</span></h3>
                     <div class="clearfix"></div>
                  </div>
                  <div class="tab4">
                     <br><br>
                     <h3 class="wthree_text_info"><span>Tab still under development</span></h3>
                     <div class="clearfix"></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- //new_arrivals --> 
      <?php
         }else {
         	echo '<br> <br> <br> <br><br> <h3 class="wthree_text_info">Welcome </h3> <br>';
         		echo ' <h3 class="wthree_text_info"><span>Please login to you <a href="#" data-toggle="modal" data-target="#myModal"> account </a></span> </h3> <br>';
         }
         ?>
      <a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
      <!-- js -->
      <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
      <!-- //js -->
      <script src="js/modernizr.custom.js"></script>
      <!-- script for responsive tabs -->						
      <script src="js/easy-responsive-tabs.js"></script>
      <script>
         $(document).ready(function () {
         $('#horizontalTab').easyResponsiveTabs({
         type: 'default', //Types: default, vertical, accordion           
         width: 'auto', //auto or any width like 600px
         fit: true,   // 100% fit in a container
         closed: 'accordion', // Start closed if in accordion view
         activate: function(event) { // Callback function if tab is switched
         var $tab = $(this);
         var $info = $('#tabInfo');
         var $name = $('span', $info);
         $name.text($tab.text());
         $info.show();
         }
         });
         $('#verticalTab').easyResponsiveTabs({
         type: 'vertical',
         width: 'auto',
         fit: true
         });
         });
      </script>
      <!-- //script for responsive tabs -->		
      <!-- stats -->
      <!-- //stats -->
      <!-- start-smoth-scrolling -->
      <script type="text/javascript" src="js/move-top.js"></script>
      <script type="text/javascript" src="js/jquery.easing.min.js"></script>
      <script type="text/javascript">
         jQuery(document).ready(function($) {
         	$(".scroll").click(function(event){		
         		event.preventDefault();
         		$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
         	});
         });
      </script>
      <!-- for bootstrap working -->
      <script type="text/javascript" src="js/bootstrap.js"></script>
   </body>
</html>