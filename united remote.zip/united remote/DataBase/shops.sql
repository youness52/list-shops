-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2019 at 06:52 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shops`
--

-- --------------------------------------------------------

--
-- Table structure for table `dislike`
--

CREATE TABLE `dislike` (
  `id` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idstore` int(11) NOT NULL,
  `dltime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dislike`
--

INSERT INTO `dislike` (`id`, `iduser`, `idstore`, `dltime`) VALUES
(1, 5, 5, 1556517085);

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(150) DEFAULT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  `n` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `name`, `address`, `latitude`, `longitude`, `image`, `n`) VALUES
(1, 'Comptoir la capital', '5,ave el maghrib el arabi', 34.0252, -6.8338, 'im1.jpg', NULL),
(2, 'Animal king', '14,ave bin al ouidane,rabat', 34.017, -6.84092, 'im2.jpg', NULL),
(3, 'achimies artisanat', 'Rue al marj rabat', 34.0198, -6.83053, 'im3.jpg', NULL),
(4, 'clinique phone', 'angle 56 av de france,rabat', 33.9968, -6.85111, 'im4.jpg', NULL),
(5, 'Rip curl surf', '5 av al atlas rabat', 33.998, -6.84576, 'im5.jpg', NULL),
(6, 'Stradivarius', '1, place othmane ibn affane', 33.994, -6.84623, 'im6.jpg', NULL),
(7, 'Zlaq surfboards', 'rue ait attab, rabat', 33.9953, -6.82771, 'im7.jpg', NULL),
(8, 'Motostore rabat', 'ave Ibn sina , Rabat', 33.9953, -6.82713, 'im8.jpg', NULL),
(9, 'WOSP maroc', 'Rue mouad, rabat', 33.9953, -6.82712, 'im9.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tlike`
--

CREATE TABLE `tlike` (
  `id` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idstore` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tlike`
--

INSERT INTO `tlike` (`id`, `iduser`, `idstore`) VALUES
(33, 2, 7),
(34, 3, 1),
(35, 3, 2),
(37, 1, 7),
(38, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password_u` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password_u`) VALUES
(1, 'youness', 'youzbair@outlook.com', '123456'),
(2, 'anas', 'youzbair@gmail.com', '1234'),
(3, 'amin', 'amin@gmail.com', '1234'),
(4, 'khalid', 'khalid@gmail.com', '1234'),
(5, 'mohamed', 'mohamed@gmail.com', '1234'),
(6, 'ahmed', 'ahmed@gmail.com', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dislike`
--
ALTER TABLE `dislike`
  ADD PRIMARY KEY (`id`),
  ADD KEY `iduser` (`iduser`),
  ADD KEY `idstore` (`idstore`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tlike`
--
ALTER TABLE `tlike`
  ADD PRIMARY KEY (`id`),
  ADD KEY `iduser` (`iduser`),
  ADD KEY `idstore` (`idstore`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dislike`
--
ALTER TABLE `dislike`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tlike`
--
ALTER TABLE `tlike`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dislike`
--
ALTER TABLE `dislike`
  ADD CONSTRAINT `dislike_ibfk_1` FOREIGN KEY (`idstore`) REFERENCES `store` (`id`),
  ADD CONSTRAINT `dislike_ibfk_2` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`);

--
-- Constraints for table `tlike`
--
ALTER TABLE `tlike`
  ADD CONSTRAINT `tlike_ibfk_1` FOREIGN KEY (`idstore`) REFERENCES `store` (`id`),
  ADD CONSTRAINT `tlike_ibfk_2` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
